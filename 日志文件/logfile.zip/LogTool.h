/**
*    File    : LogTool.h
*    Author  : shendongming
*    Date    : 9/4/2010
*    Function: ��־���ʵ��ͷ�ļ�
*/

#ifndef __LOG_TOOL_H__
#define __LOG_TOOL_H__

#include "LogFile.h"

//*****************������־������־��ӡ����********************//
enum enLogLevel
{
    LOG_FATAL = 0,
    LOG_ERROR = 3, 
    LOG_WARNING = 4,
    LOG_INFO = 6,
    LOG_DEBUG = 7,
};

//��־�ļ�·��,���ִ���ļ�ͬ��
const std::string LOGFILE = "VideoMonitorLog";

void _cdecl log_message(UINT iLogLevel,char *format, ...);
void _cdecl set_log_level(int iLogLevel);


#ifndef MAX_LOG_LENGTH
#define MAX_LOG_LENGTH 2048
#endif

#ifndef PC_TRACE
#define PC_TRACE strFile = (char*)__FILE__ ; iLine = __LINE__ ;log_message
#endif

#ifndef PC_SET_LOGLEVEL
#define PC_SET_LOGLEVEL set_log_level
#endif

//Windows�µ���
class CLock
{
    CRITICAL_SECTION cs;
public:
    CLock()
    {
        InitializeCriticalSection(&cs);
    }
    ~CLock()
    {
        DeleteCriticalSection(&cs);
    }
    void lockOn()
    {
        EnterCriticalSection(&cs);
    }
    void lockOff()
    {
        LeaveCriticalSection(&cs);
    }
};

#endif